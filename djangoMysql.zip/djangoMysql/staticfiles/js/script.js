function clicar() {
	alert('Funcionando...');
}