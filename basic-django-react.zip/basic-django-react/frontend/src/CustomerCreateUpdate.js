import React, { Component } from 'react';

import ConsumidoresService from './ConsumidoresService';

const ConsumidoresService = new ConsumidoresService();

class ConsumidorCreateUpdate extends Component {
    constructor(props) {
        super(props);
    
        //this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }

      componentDidMount(){
        const { match: { params } } = this.props;
        if(params && params.pk)
        {
          ConsumidoresService.getConsumidor(params.pk).then((c)=>{
            this.refs.firstName.value = c.nome;
            this.refs.lastName.value = c.sobrenome;
            this.refs.email.value = c.email;
            this.refs.telefone.value = c.telefone;
            this.refs.endereco.value = c.endereco;
            this.refs.descricao.value = c.descricao;
          })
        }
      }

      handleCreate(){
        ConsumidoresService.createConsumidor(
          {
            "nome": this.refs.firstName.value,
            "sobrenome": this.refs.lastName.value,
            "email": this.refs.email.value,
            "telefone": this.refs.telefone.value,
            "endereco": this.refs.endereco.value,
            "descricao": this.refs.descricao.value
        }          
        ).then((result)=>{
          alert("Consumidor created!");
        }).catch(()=>{
          alert('There was an error! Please re-check your form.');
        });
      }
      handleUpdate(pk){
        ConsumidoresService.updateConsumidor(
          {
            "pk": pk,
            "nome": this.refs.firstName.value,
            "sobrenome": this.refs.lastName.value,
            "email": this.refs.email.value,
            "telefone": this.refs.telefone.value,
            "endereco": this.refs.endereco.value,
            "descricao": this.refs.descricao.value
        }          
        ).then((result)=>{
          console.log(result);
          alert("Consumidor updated!");
        }).catch(()=>{
          alert('There was an error! Please re-check your form.');
        });
      }
      handleSubmit(event) {
        const { match: { params } } = this.props;

        if(params && params.pk){
          this.handleUpdate(params.pk);
        }
        else
        {
          this.handleCreate();
        }

        event.preventDefault();
      }
    
      render() {
        return (
          <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label>
              Nome:</label>
              <input className="form-control" type="text" ref='firstName' />
            
            <label>
              Sobrenome:</label>
              <input className="form-control" type="text" ref='lastName'/>
            
            <label>
              telefone:</label>
              <input className="form-control" type="text" ref='telefone' />
            
            <label>
              Email:</label>
              <input className="form-control" type="text" ref='email' />
            
            <label>
              endereco:</label>
              <input className="form-control" type="text" ref='endereco' />
            
            <label>
              descricao:</label>
              <textarea className="form-control" ref='descricao' ></textarea>
              

            <input className="btn btn-primary" type="submit" value="Submit" />
            </div>
          </form>
        );
      }  
}

export default ConsumidorCreateUpdate;