import axios from 'axios';
const API_URL = 'http://localhost:8000';

export default class ConsumidoresService{
	
	constructor(){}

	getConsumidores() {
        console.log("get Consumidores");
		const url = `${API_URL}/api/Consumidores/`;
		return axios.get(url).then(response => response.data);
	}

	getConsumidoresByURL(link){
		const url = `${API_URL}${link}`;
		return axios.get(url).then(response => response.data);
	}

	getConsumidor(pk) {
		const url = `${API_URL}/api/Consumidores/${pk}`;
		return axios.get(url).then(response => response.data);
	}

	deleteConsumidor(Consumidor){
		const url = `${API_URL}/api/Consumidores/${Consumidor.pk}`;
		return axios.delete(url);
	}

	createConsumidor(Consumidor){
		const url = `${API_URL}/api/Consumidores/`;
		return axios.post(url,Consumidor);
	}

	updateConsumidor(Consumidor){
		const url = `${API_URL}/api/Consumidores/${Consumidor.pk}`;
		return axios.put(url,Consumidor);
	}
}