import React, { Component } from 'react';
import ConsumidoresService from './ConsumidoresService';

const ConsumidoresService = new ConsumidoresService();

class ConsumidoresList extends Component {
  
  constructor(props) {
    super(props);

    this.state = {
      Consumidores: [],
      nextPageURL: ''

    };
    this.nextPage = this.nextPage.bind(this);
    this.handleDelete = this.handleDelete.bind(this);

    
  }  
  componentDidMount() {
    var self = this;
    ConsumidoresService.getConsumidores().then(function (result) {
      console.log(result);
      self.setState({ Consumidores: result.data, nextPageURL: result.nextlink})
    });
  }

  handleDelete(e,pk){

    var self = this;
    ConsumidoresService.deleteConsumidor({pk : pk}).then(()=>{
      var newArr = self.state.Consumidores.filter(function(obj) {
        return obj.pk !== pk;
      });

      self.setState({Consumidores: newArr})
    });
    
  }
  
  nextPage(){
    var self = this;
    console.log(this.state.nextPageURL);
    ConsumidoresService.getConsumidoresByURL(this.state.nextPageURL).then((result) => {

      self.setState({ Consumidores: result.data, nextPageURL: result.nextlink})

    });      
    
  }

  render() {
    return (
      <div className="Consumidores--list">
          <table className="table">
          <thead key="thead">
          <tr>
            <th>#</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>telefone</th>
            <th>Email</th>
            <th>endereco</th>
            <th>descricao</th>   
            <th>Actions</th>   
          </tr>
          </thead>

            <tbody>
            {this.state.Consumidores.map( c =>

              <tr key={c.pk}>
                <td>{c.pk} </td>
                <td>{c.nome}</td>
                <td>{c.sobrenome}</td>
                <td>{c.telefone}</td>
                <td>{c.email}</td>
                <td>{c.endereco}</td>
                <td>{c.descricao}</td>
                <td>
                <button  onClick={(e)=> this.handleDelete(e,c.pk) }> Delete</button>
                <a  href={"/Consumidor/" + c.pk}> Update</a> 
                </td>
              </tr>)}
              </tbody>
          </table>  
          <button className="btn btn-primary" onClick= { this.nextPage }>Next</button>

      </div>
    );
  }
}

export default ConsumidoresList;
