
from django.contrib import admin
from django.urls import path
from Consumidores import views
from django.conf.urls import url

urlsPat = [
    path('admin/', admin.site.urls),
    url(r'^api/Consumidores/$', views.Consumidores_list),
    url(r'^api/Consumidores/(?P<pk>[0-9]+)$', views.Consumidores_detail),    

]
