from django.db import models

class Consumidor(models.Model):
	nome = models.CharField("Nome", , null=True, max_length=200)
	endereco =  models.TextField(blank=True, null=True)
	sobrenome = models.CharField("Sobrenome", max_length=100)
	email = models.EmailField()
	telefone = models.CharField(max_length=20)
	descricao = models.TextField(blank=True, null=True)
	criadoEm = models.DateTimeField("Criado em", auto_now_add=True)
	
	def __str__(self):
		return self.nome