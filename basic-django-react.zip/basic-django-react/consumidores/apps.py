from django.apps import AppConfig


class ConsumidoresConfig(AppConfig):
    name = 'Consumidores'
