from rest_framework import serializers
from .models import Consumidor

class Consumidoreserializer(serializers.ModelSerializer):

    class Meta:
        model = Consumidor 
        fields = ('pk','nome', 'sobrenome', 'email', 'telefone','endereco','descricao')
        