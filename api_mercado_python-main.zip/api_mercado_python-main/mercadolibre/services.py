import json
import logging

import pandas as pd
import numpy as np
import requests


class MercadoLibre:
    def __init__(self):
        self.response = self.__get_data_api()

    def __response_to_dataframe(self):
        return pd.DataFrame.from_dict([
            {
                'seller': i['seller'].get('eshop', {}).get('nick_name'),
                'quantity': i['sold_quantity'],
                'price': i['price'],
                'link': i['permalink'],
                'product': i['title'],
                'image_seller': i['seller'].get('eshop', {}).get('eshop_logo_url'),
                'image': i['thumbnail']
            } for i in self.response
        ])

    def __get_data_api(self):
        data = []

        try:
            endpoint = ('https://api.mercadolibre.com/'
                        'sites/MLA/search?category=MLA420040'
                        '&offset={offset}&limit={limit}')

            logging.info('Starting Data Request for MercadoLibre API')

            r = requests.get(
                endpoint.format(offset=0, limit=50)
            ).json()
            data.extend(r['results'])

            for offset in range(0, r['paging']['total'], 50):
                if offset == 0:
                    continue

                r_2_step = requests.get(
                    endpoint.format(offset=0, limit=50)
                ).json()
                data.extend(r_2_step['results'])


        except Exception as e:
            logging.exception(('Error when requesting data '
                               'for MercadoLivre: %s') % e)
        return data

    def best_sellers(self, limit):
        best_sellers = self.__response_to_dataframe()\
            .groupby(['seller'])[['seller', 'quantity']]\
            .sum()\
            .sort_values('quantity', ascending=False)\
            .reset_index()

        best_sellers.replace('', np.nan, inplace=True)
        best_sellers.dropna(inplace=True)

        return best_sellers[:limit].to_dict('index').items()

    def expensive_products(self, limit):
        return self.__response_to_dataframe()[
                    ['product', 'price', 'link', 'image', 'image_seller']
               ].groupby('product').first().sort_values(
                   'price', ascending=False
               ).reset_index()[:limit].to_dict(
                   'index'
               ).items()
