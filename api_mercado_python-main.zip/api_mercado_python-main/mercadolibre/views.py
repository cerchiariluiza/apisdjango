from django.shortcuts import render

from .services import MercadoLibre


def index(request):
    return render(request, 'mercadolibre/homepage.html')


def best_sellers(request):
    return render(request, 'mercadolibre/best_sellers.html', {
        'best_sellers': MercadoLibre().best_sellers(limit=10)
    })


def expensive_products(request):
    return render(request, 'mercadolibre/expensive_products.html', {
        'expensive_products': MercadoLibre().expensive_products(limit=10)
    })
