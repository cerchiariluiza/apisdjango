import asyncio
import aiohttp
import pathlib
import logging
import json


ENDPOINT = ('https://api.mercadolibre.com/'
            'sites/MLA/search?category=MLA420040'
            '&offset={offset}&limit=50')


async def fetch(session, page_offset):
    async with session.get(ENDPOINT.format(offset=page_offset)) as response:
        return await response.json()

async def mercadolibre():
    async with aiohttp.ClientSession() as session:
        logging.info('Request for MercadoLibre API is running...')
        req = await session.get(
            ENDPOINT.format(offset=0)
        )
        response = await req.json()

        logging.info('Initial request finalized...')

        n_itens = response['paging']['total']
        requests_offset = [x for x in range(50, n_itens, 50)]

        logging.info((f'Total "{n_itens}" items in the API with '
                      f'"{requests_offset}" Requests for total rescue'))

        pool_requests = [
            fetch(session, offset)
            for offset in requests_offset
        ] if response['paging']['total'] > 50 else []


        return (response,
                await asyncio.gather(*pool_requests, return_exceptions=True))

if __name__ == '__main__':
    r, r2 = asyncio.run(mercadolibre())
    r2.insert(0, r)

    with pathlib.Path('/tmp/foobar.txt').open('w') as s:
        s.write(json.dumps(r2))
