from django.apps import AppConfig


class MercadolibreConfig(AppConfig):
    name = 'mercadolibre'
