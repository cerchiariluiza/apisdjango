from django.test import TestCase

from .services import MercadoLibre


class TestMercadoLibre(TestCase):
    # def setUp(self):
    #     self.ml = MercadoLibre()

    def test_service_mercadolibre_data(self):
        ml = MercadoLibre()
        self.assertTrue(isinstance(ml.response, list))

    def test_error_service_mercadolibre_request(self):
        ml = MercadoLibre()
        self.assertTrue(isinstance(ml.response, list))

    # def test_best_seller(self):
    #     self.assertEqual(self.ml.best_sellers(), [
    #         {'seller': 'x-seller', 'quantity': 30}
    #         {'seller': 'y-seller', 'quantity': 20}
    #         {'seller': 'z-seller', 'quantity': 6}
    #     ])

    # def test_expensive_products(self):
    #     self.assertEqual(self.ml.expensive_products(), [
    #         {'product': 'x-product', 'quantity': 20.90}
    #         {'product': 'y-product', 'quantity': 40.90}
    #     ])

